USE xl_fsl_acctg_events_db
GO

select Current_Database,TableName,max(StatisticUpdateDate) as 'StatisticUpdateDate' from
(
select DB_NAME() AS [Current_Database],OBJECT_NAME(s.object_id) AS [TableName],
STATS_DATE(s.object_id, [stats_id]) AS [StatisticUpdateDate]
FROM sys.stats s inner join sys.objects o on
s.object_id = o.object_id 
where o.type not in ('S','IT','SQ') 
and OBJECT_NAME(s.object_id) IN 
(
't_f_xlf_wp_policy_transaction',
't_r_aej_tran_type_lookup',
't_r_aej_ioc_ind',
't_f_xlf_ioc_transaction',
't_f_xlf_ceded_dac',
't_f_xlf_ceded_dac_ll_adj',
't_f_xlf_ceded_upr',
't_f_xlf_ceded_upr_ll_adj',
't_f_xlf_dac',
't_f_xlf_dac_ll',
't_f_xlf_dac_ll_adj',
't_f_xlf_upr',
't_f_xlf_upr_ll',
't_f_xlf_upr_ll_adj'
)
) as a
group by Current_Database,TableName
Order by [StatisticUpdateDate] desc

------------------------------------------------------------------------------------------------

USE [AutosysQA]
GO
select DB_NAME() AS [Current Database],OBJECT_NAME(s.object_id) AS [ObjectName],s.name,
STATS_DATE(s.object_id, [stats_id]) AS [StatisticUpdateDate]
FROM sys.stats s inner join sys.objects o on
s.object_id = o.object_id 
where o.type not in ('S','IT','SQ') 
--and OBJECT_NAME(s.object_id) IN 
--(
----'xl_document_r'
----,'xlins_subs_risk_doc_r'
----'t_f_xle_fah_detail_as_was'
----'t_f_xle_fah_detail_as_is '
--)
Order by [StatisticUpdateDate] desc

---------------------------------------------------------------------------------------------------------------

SELECT OBJECT_name(OBJECT_ID) TabName, 
       name IndexName,
       STATS_DATE(OBJECT_ID, index_id) AS StatsUpdated, type_desc, type, index_id,fill_factor,is_disabled
       --getdate() CheckTime
FROM sys.indexes WHERE 
 DATEDIFF(d,STATS_DATE(OBJECT_ID, index_id), getdate()) > 6 and OBJECT_name(OBJECT_ID) not like '%sys%'
--name like '%i_receipt%'
-- object_id
-- in ('1358679938',
--'1490820373')
ORDER BY 3 DESC
