exec master.dbo.xp_restore_verifyonly
@filename = N'\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full1.sls',
@filename = N'\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full2.sls',
@filename = N'\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full3.sls',
@filename = N'\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full4.sls',
@filename = N'\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full5.sls',
@filename = N'\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full6.sls',
@filename = N'\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full7.sls',
@filename = N'\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full8.sls',
@filenumber = 1,
@logging = 0

	--\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full1.sls
	--\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full2.sls
	--\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full3.sls
	--\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full4.sls
	--\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full5.sls
	--\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full6.sls
	--\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full7.sls
	--\\Ewrss0081\k$\MSSQLDumps\DMS_RITM0869840_20190808\dmp_dw_xlre_am_full8.sls