EXEC xp_logininfo 'CATLIN\Application Access - Central Pricing Models SQL Admin','members';  

EXEC xp_logininfo 'CATLIN\rmoss','all';  
