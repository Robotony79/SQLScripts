
SELECT name, physical_name AS NewLocation, state_desc AS OnlineStatus
FROM sys.master_files  
WHERE database_id = DB_ID(N'warehouseadmin_xle_ofcyl')  
GO

--from: M:\MSSQL\Data\warehouseadmin_xle_dat1.mdf  --COMPLETE
ALTER DATABASE warehouseadmin_xle_ofcyl   
    MODIFY FILE ( NAME = warehouseadmin_xle,   
                  FILENAME = 'D:\MSSQL\Data\warehouseadmin_xle_dat1.mdf');  
GO

 --this is for log
 --from: G:\MSSQL\Log\warehouseadmin_xle_log1.ldf
ALTER DATABASE warehouseadmin_xle_ofcyl   
    MODIFY FILE ( NAME = warehouseadmin_xle_log,   
                  FILENAME = 'D:\MSSQL\Log\warehouseadmin_xle_log1.ldf');  

ALTER DATABASE warehouseadmin_xle_ofcyl SET OFFLINE WITH ROLLBACK IMMEDIATE; 
GO
--COPY FILES MANUALLY

ALTER DATABASE warehouseadmin_xle_ofcyl SET ONLINE;  
GO 
