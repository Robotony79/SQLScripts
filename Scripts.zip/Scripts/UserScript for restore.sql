
exec master.dbo.xp_restore_database @database = N'sweety' ,
@filename = N'sweety',
@with = N'REPLACE',
@filenumber = 1,
@with = N'STATS = 10',
@with = N'MOVE N''procede_dat1'' TO N''D:\MSSQL\Data\procede_qa1.mdf''',
@with = N'MOVE N''procede_log1'' TO N''G:\MSSQL\Log\procede_qa1_log.ldf''',
@affinity = 0,
@logging = 0


GO
-------------
Exec master..xp_restore_filelistonly @filename=''
