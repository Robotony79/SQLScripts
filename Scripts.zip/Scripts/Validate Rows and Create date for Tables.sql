use [dw_xlre_am_backup]
go
if OBJECT_ID('tempdb..#Tables_Space') is not null
DROP TABLE #Tables_Space

CREATE TABLE #Tables_Space
(
Database_Name varchar(40),
Table_name varchar(200),
Table_rows int,
Create_date varchar(40)
)

if OBJECT_ID('tempdb..#TMP') is not null
DROP TABLE #TMP

CREATE TABLE #TMP
(
Table_Name VARCHAR(200),
Table_Rows INT,
Table_Reserved VARCHAR(200),
Table_Data VARCHAR(200),
Table_IX VARCHAR(200),
Table_Unused VARCHAR(200)
)


DECLARE @dbname VARCHAR(200)
DECLARE @name VARCHAR(200) 
DECLARE @create_date VARCHAR(40)

DECLARE db_cursor CURSOR FOR 

select DB_NAME() as 'DB',name,CONVERT(VARCHAR(40),create_date,120) from sys.tables
where type='U'
order by 2

OPEN db_cursor FETCH 
NEXT FROM db_cursor 
INTO @dbname,@name, @create_date

WHILE @@FETCH_STATUS = 0  
BEGIN  

	DECLARE @q nvarchar(4000)
	SET @q = 'sp_spaceused ' +'''' + @name + ''''

	INSERT INTO #TMP
	EXEC(@q)

	INSERT INTO #Tables_Space
	SELECT @dbname, @name,(SELECT DISTINCT TABLE_ROWS FROM #TMP where TABLE_NAME=@name) as 'Rows', @create_date
	
FETCH NEXT FROM db_cursor     
INTO @dbname, @name, @create_date

END 

CLOSE db_cursor  
DEALLOCATE db_cursor

go

select * from #Tables_Space
order by Create_date