use [dbrestore_prod]
GO

/*server details: xlgc-ods-qa1
Application name : EMI
AD group name for which access required : EMI Developer
Mail DL for email notifications : XLC-MI-Hartford-SmallChange-DL*/

/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [id]
      ,[AD_Group_Name]
      ,[application_name]
      ,[email]
      ,[request_number]
  --Select *    where email is null
  FROM [dbrestore_prod].[dbo].[tbl_ad_login] 
       where AD_Group_Name like '%EMI Developer%'
	   AND application_name='EMI'
--where ID in (1,9,14)

SELECT * FROM [dbo].[tbl_sql_source_instance_name] 
where --sql_instance_name like '%xlgc-ods-qa1%' 
AD_GROUP_ID in (90,92,119)
-- (SELECT ID from [dbo].[tbl_ad_login] where AD_Group_Name like '%Procede%')

SELECT * FROM [dbo].[tbl_sql_target_instance_name] where 
sql_instance_name like '%xlgc-ods-qa1%' 
--ID in (1,9,14)
--(SELECT ID from [dbo].[tbl_ad_login] where AD_Group_Name like '%Procede%')

Select distinct AD_GRoup_name FROM [dbrestore_prod].[dbo].[tbl_ad_login] 
--Create Login that will add Identity AD_GROUP_ID
USE [dbrestore_prod]
GO
INSERT INTO [dbo].[tbl_ad_login]
           ([AD_Group_Name]
           ,[application_name]
           ,[email]
           ,[request_number])
     VALUES
           ('R02 DLG XLC Re AMS App Team'
                 ,'Reinsurance Application support team'
           ,''
           ,'RITM0700178')
GO
--Insert Source Server usually Production server
USE [dbrestore_prod]
GO
INSERT INTO [dbo].[tbl_sql_source_instance_name]
           ([sql_instance_name]
           ,[ad_group_id])
     VALUES
           ('xlgc-ods-qa1'
           ,92)
GO

--Insert Target server NON Production Servers only
USE [dbrestore_prod]
GO
INSERT INTO [dbo].[tbl_sql_target_instance_name]
           ([sql_instance_name]
           ,[ad_group_id])
     VALUES
           ('xlgc-ods-qa1'
           ,92)
GO


--Additional queries
Update [dbo].[tbl_ad_login] 
set [AD_Group_Name]='EDW DLG XACT DB Developer'
where id = 114

Update [dbo].[tbl_ad_login] 
set email='XLC-MI-Hartford-SmallChange-DL@xlcatlin.com',
request_number='RITM0624441,RITM0743816'
where id = 92

select * from tbl_ad_login where id =92


