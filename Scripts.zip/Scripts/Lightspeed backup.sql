exec master.dbo.xp_backup_database
@database = N'Sp_legacy_submission_test4',
@backupname = N'Sp_legacy_submission_test4 - Full Database Backup',
@desc = N'Full Backup of Sp_legacy_submission_test4',
@compressionlevel = 2,
@filename = N'K:\MSSQLDumps\DMS_RITM0728053_20181225\dmp_Sp_legacy_submission_test4_full.sls',
@init = 0, 
@with = N'STATS = 10',
@with = N'COPY_ONLY' 
GO
