USE admin 
GO
SELECT    [TableName] = name,
create_date,
modify_date
FROM    sys.tables
WHERE    name in  ('UWLI_combined_data_basetable_RITM0407903');


