--2008
SELECT  CAST(event_data.value('(event/data/value)[1]',
                               'varchar(max)') AS XML) AS DeadlockGraph
FROM    ( SELECT    XEvent.query('.') AS event_data
          FROM      (    -- Cast the target_data to XML 
                      SELECT    CAST(target_data AS XML) AS TargetData
                      FROM      sys.dm_xe_session_targets st
                                JOIN sys.dm_xe_sessions s
                                 ON s.address = st.event_session_address
                      WHERE     name = 'system_health'
                                AND target_name = 'ring_buffer'
                    ) AS Data -- Split out the Event Nodes 
                    CROSS APPLY TargetData.nodes('RingBufferTarget/
                                     event[@name="xml_deadlock_report"]')
                    AS XEventData ( XEvent )
        ) AS tab ( event_data ) 

-- Retrieve from Extended Events in 2012
SELECT  XEvent.query('(event/data/value/deadlock)[1]') AS DeadlockGraph
FROM    ( SELECT    XEvent.query('.') AS XEvent
          FROM      ( SELECT    CAST(target_data AS XML) AS TargetData
                      FROM      sys.dm_xe_session_targets st
                                JOIN sys.dm_xe_sessions s
                                 ON s.address = st.event_session_address
                      WHERE     s.name = 'system_health'
                                AND st.target_name = 'ring_buffer'
                    ) AS Data
                    CROSS APPLY TargetData.nodes
                  ('RingBufferTarget/event[@name="xml_deadlock_report"]')
                    AS XEventData ( XEvent )
        ) AS src;   

/*new one*/
DECLARE @version int 
SET @version = (@@microsoftversion / 0x1000000) & 0xff; 
IF (@version = 10) 
BEGIN 
WITH SystemHealth 
AS ( 
SELECT CAST(target_data as xml) AS TargetData 
FROM sys.dm_xe_session_targets st 
       JOIN sys.dm_xe_sessions s ON s.address = st.event_session_address 
WHERE name = 'system_health' 
       AND st.target_name = 'ring_buffer') 
SELECT XEventData.XEvent.value('(data/value)[1]','VARCHAR(MAX)') AS DeadLockGraph 
FROM SystemHealth 
       CROSS APPLY TargetData.nodes('//RingBufferTarget/event') AS XEventData (XEvent) 
WHERE XEventData.XEvent.value('@name','varchar(4000)') = 'xml_deadlock_report' 
END 
IF (@version > 10) 
BEGIN 
WITH SystemHealth 
AS ( 
SELECT CAST(target_data as xml) AS TargetData 
FROM sys.dm_xe_session_targets st 
       JOIN sys.dm_xe_sessions s ON s.address = st.event_session_address 
WHERE name = 'system_health' 
AND st.target_name = 'ring_buffer') 
SELECT XEventData.XEvent.query('(data/value/deadlock)[1]') AS DeadLockGraph 
FROM SystemHealth 
       CROSS APPLY TargetData.nodes('//RingBufferTarget/event') AS XEventData (XEvent) 
WHERE XEventData.XEvent.value('@name','varchar(4000)') = 'xml_deadlock_report' 
END


--
SELECT XEvent.query('(event/data/value/deadlock)[1]') AS DeadlockGraph
FROM (
    SELECT XEvent.query('.') AS XEvent
    FROM (
        SELECT CAST(target_data AS XML) AS TargetData
        FROM sys.dm_xe_session_targets st
        INNER JOIN sys.dm_xe_sessions s ON s.address = st.event_session_address
        WHERE s.NAME = 'system_health'
            AND st.target_name = 'ring_buffer'
        ) AS Data
CROSS APPLY TargetData.nodes('RingBufferTarget/event[@name="xml_deadlock_report"]') AS XEventData(XEvent)
) AS source;

CREATE TABLE #errorlog (
						LogDate DATETIME 
						, ProcessInfo VARCHAR(100)
						, [Text] VARCHAR(MAX)
						);

DECLARE @tag VARCHAR (MAX) , @path VARCHAR(MAX);

INSERT INTO #errorlog EXEC sp_readerrorlog;

SELECT @tag = text
FROM #errorlog 
WHERE [Text] LIKE 'Logging%MSSQL\Log%';

DROP TABLE #errorlog;

SET @path = SUBSTRING(@tag, 38, CHARINDEX('MSSQL\Log', @tag) - 29);

SELECT 
	CONVERT(xml, event_data).query('/event/data/value/child::*') AS DeadlockReport,
	CONVERT(xml, event_data).value('(event[@name="xml_deadlock_report"]/@timestamp)[1]', 'datetime') 
	AS Execution_Time
FROM sys.fn_xe_file_target_read_file(@path + '\system_health*.xel', NULL, NULL, NULL)
WHERE OBJECT_NAME like 'xml_deadlock_report';