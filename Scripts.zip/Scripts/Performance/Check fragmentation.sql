set transaction isolation level read uncommitted
USE [dw_xlre_am]
go

SELECT OBJECT_NAME(ind.object_id) AS TableName,ind.object_id,
ind.name AS IndexName, indexstats.index_type_desc AS IndexType,
indexstats.avg_fragmentation_in_percent, page_count,ind.fill_factor,ind.is_disabled
FROM sys.dm_db_index_physical_stats (DB_ID(),null,null,null,null) indexstats  --FOR SOME 2008 Versions DB_ID IS NOT WORKING FIND THE DB ID AND SET IN THIS QUERY
INNER JOIN sys.indexes ind 
ON ind.object_id = indexstats.object_id
AND ind.index_id = indexstats.index_id
WHERE 
--and 
--indexstats.index_type_desc <> 'HEAP'--
 --AND 
 OBJECT_NAME(ind.OBJECT_ID) LIKE '%t_f_xle_accrual_movement%' OR OBJECT_NAME(ind.OBJECT_ID) LIKE '%t_accounting_period%'
--OR 
--and 
--indexstats.avg_fragmentation_in_percent > 10 
--and page_count> 100
ORDER BY --page_count DESC --, 
indexstats.avg_fragmentation_in_percent desc


--Second Script
DECLARE @db_id SMALLINT;
DECLARE @object_id INT;
SET @db_id = DB_ID(N'istreamdmotcs');
SET @object_id = OBJECT_ID(N'Null');
IF @object_id IS NULL 
BEGIN
   PRINT N'Invalid object';
END
ELSE
BEGIN
   SELECT IPS.Index_type_desc, 
      IPS.avg_fragmentation_in_percent, 
      IPS.avg_fragment_size_in_pages, 
      IPS.avg_page_space_used_in_percent, 
      IPS.record_count, 
      IPS.ghost_record_count,
      IPS.fragment_count, 
      IPS.avg_fragment_size_in_pages
   FROM sys.dm_db_index_physical_stats(@db_id, @object_id, NULL, NULL , 'DETAILED') AS IPS;
END
GO


--Third script

set transaction isolation level read uncommitted
USE [istreamdmotcs]
go
SELECT o.name, i.name, partition_number, avg_fragmentation_in_percent, index_type_desc,page_count
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, 'LIMITED') AS ps 
JOIN sys.objects AS o ON ps.object_id = o.object_id 
JOIN sys.indexes AS i ON ps.index_id = i.index_id AND i.object_id = ps.object_id 
WHERE ps.avg_fragmentation_in_percent > 0.0 AND ps.index_id > 0 
ORDER BY avg_fragmentation_in_percent DESC