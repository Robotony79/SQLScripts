EXEC sp_configure 'max degree of parallelism';
GO
EXEC sp_configure 'max server memory (MB)';
GO

select 524158/1024

SELECT
   name
  ,request_max_memory_grant_percent
FROM sys.dm_resource_governor_workload_groups
WHERE name = 'default';
GO

stg.t_f_fah_gl_month_as_is_30

SELECT session_id,DB_NAME(DATABASE_ID),
text,
query_plan
FROM sys.dm_exec_requests
CROSS APPLY sys.dm_exec_sql_text(sql_handle)
CROSS APPLY sys.dm_exec_query_plan(plan_handle) ;


SELECT open_tran,* FROM sys.sysprocesses
where blocked<>0--Here you will get the blocking id.
GO

select * from sys.dm_os_ring_buffers
where record LIKE '%RING_BUFFER_RESOURCE_MONITOR%'
select * from sys.dm_os_ring_buffers
where record LIKE '%RESOURCE_MEMPHYSICAL_LOW%'


SELECT 
(physical_memory_in_use_kb/1024) AS Memory_usedby_Sqlserver_MB, 
(locked_page_allocations_kb/1024) AS Locked_pages_used_Sqlserver_MB, 
(total_virtual_address_space_kb/1024) AS Total_VAS_in_MB, 
process_physical_memory_low, 
process_virtual_memory_low 
FROM sys.dm_os_process_memory; 