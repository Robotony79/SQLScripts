(SELECT Max(v)
FROM (VALUES (avg_cpu_percent),(avg_data_io_percent),(avg_log_write_percent)) AS value(v)) AS [avg_DTU_percent]

ISNULL (dtu_limit,0) * 
		SELECT Max(v)
FROM (VALUES (avg_cpu_percent),(avg_data_io_percent),(avg_log_write_percent)) AS value(v)) /100.0 AS [DTU]

SELECT captureDate, WaitType, Wait_s,Resource_S, Signal_S,WaitCount, Avg_wait_S FROM Waits.WaitStats
WHERE Wait_S > 1
ORDER BY CaptureDate desc, Wait_S desc
