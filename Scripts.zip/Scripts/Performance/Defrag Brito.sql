
DECLARE @reorg_frag_thresh   float		SET @reorg_frag_thresh   = 05.0
DECLARE @rebuild_frag_thresh float		SET @rebuild_frag_thresh = 20.0
DECLARE @fill_factor         tinyint	SET @fill_factor         = 80
DECLARE @report_only         bit		SET @report_only         = 0

-- added (DS) : page_count_thresh is used to check how many pages the current table uses
DECLARE @page_count_thresh	 smallint	SET @page_count_thresh   = 1
 
-- Variables required for processing.
DECLARE @objectid       int
DECLARE @indexid        int
DECLARE @partitioncount bigint
DECLARE @schemaname     nvarchar(130) 
DECLARE @objectname     nvarchar(130) 
DECLARE @indexname      nvarchar(130) 
DECLARE @partitionnum   bigint
DECLARE @partitions     bigint
DECLARE @frag           float
DECLARE @page_count     int
DECLARE @isonline		bit
DECLARE @command        nvarchar(4000)
DECLARE @command1       nvarchar(4000)
DECLARE @intentions     nvarchar(4000)
DECLARE @isEnterprise	bit



SET @isEnterprise	=	0

IF SUBSTRING(CAST(SERVERPROPERTY ('edition') AS VARCHAR(50)),1,5) = 'ENTER'
BEGIN
SET @isEnterprise	=	1
END


DECLARE	@tbl_var TABLE (
                          objectid     int,
                          indexid      int,
                          partitionnum int,
                          frag         float,
						  page_count   int,
						  isonline	   bit
                        )
                        
 

INSERT INTO
    @tbl_var
SELECT
    [object_id]										AS objectid,
    [index_id]										AS indexid,
    [partition_number]								AS partitionnum,
    [avg_fragmentation_in_percent]					AS frag,
	[page_count]									AS page_count,
	1												AS isonline
FROM
    sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL , NULL, 'LIMITED')
WHERE
    [avg_fragmentation_in_percent] > @reorg_frag_thresh 
	AND
	page_count > @page_count_thresh
	AND
    index_id > 0
	
	
	
UPDATE	@tbl_var	
		SET		isonline =0
		FROM @tbl_var tv JOIN  sys.indexes si 
				ON	tv.indexid = si.index_id
				AND	tv.objectid = si.object_id
		WHERE	si.type = 3


UPDATE	@tbl_var	
		SET		isonline =0
		FROM @tbl_var tv JOIN  sys.indexes si 
				ON	tv.indexid = si.index_id
				AND	tv.objectid = si.object_id
			  
			  JOIN   sys.columns sc
							   ON            si.object_id  =      sc.object_id
									  JOIN   sys.systypes  st
							   ON            st.xtype      = sc.system_type_id
									  JOIN	 sys.index_columns sic
							   ON			 si.index_id   = sic.index_id 
				WHERE
				  			  
				  (si.index_id		=      1  AND	(st.name in ('text', 'ntext', 'image')          OR            sc.max_length =-1))
				  
				 OR
				  
  				  (sic.is_included_column =1 AND           si.index_id   >      1
						AND           (st.name in ('text', 'ntext', 'image')          OR            sc.max_length =-1))	
	
	
	
	
	
 
DECLARE partitions CURSOR FOR
    SELECT * FROM @tbl_var
 
OPEN partitions
 
WHILE (1=1) BEGIN
    FETCH NEXT
        FROM partitions
        INTO @objectid, @indexid, @partitionnum, @frag, @page_count, @isonline
 
    IF @@FETCH_STATUS < 0 BREAK
 
    SELECT
        @objectname = QUOTENAME(o.[name]),
        @schemaname = QUOTENAME(s.[name])
    FROM
        sys.objects AS o WITH (NOLOCK)
        JOIN sys.schemas as s WITH (NOLOCK)
        ON s.[schema_id] = o.[schema_id]
    WHERE
        o.[object_id] = @objectid
 
    SELECT
        @indexname = QUOTENAME([name])
    FROM
        sys.indexes WITH (NOLOCK)
    WHERE
        [object_id] = @objectid AND
        [index_id] = @indexid
 
    SELECT
        @partitioncount = count (*)
    FROM
        sys.partitions WITH (NOLOCK)
    WHERE
        [object_id] = @objectid AND
        [index_id] = @indexid
 
    SET @intentions =
        @schemaname + N'.' +
        @objectname + N'.' +
        @indexname + N':' + CHAR(13) + CHAR(10)
    SET @intentions =
        REPLACE(SPACE(LEN(@intentions)), ' ', '=') + CHAR(13) + CHAR(10) +
        @intentions
    SET @intentions = @intentions +
        N' FRAGMENTATION: ' + CAST(@frag AS nvarchar) + N'%' + CHAR(13) + CHAR(10) +
        N' PAGE COUNT: '    + CAST(@page_count AS nvarchar) + CHAR(13) + CHAR(10)
 
    IF @frag < @rebuild_frag_thresh BEGIN
        SET @intentions = @intentions +
            N' OPERATION: REORGANIZE' + CHAR(13) + CHAR(10)
        SET @command =
            N'ALTER INDEX ' + @indexname +
            N' ON ' + @schemaname + N'.' + @objectname +
            N' REORGANIZE; ' 
            + N' UPDATE STATISTICS ' + @schemaname + N'.' + @objectname + 
            N' ' + @indexname + ';'

    END
    IF @frag >= @rebuild_frag_thresh BEGIN
        SET @intentions = @intentions +
            N' OPERATION: REBUILD' + CHAR(13) + CHAR(10)
        SET @command =
            N'ALTER INDEX ' + @indexname +
            N' ON ' + @schemaname + N'.' +     @objectname +
            N' REBUILD'
    END
    IF @partitioncount > 1 
		BEGIN
        SET @intentions = @intentions +
            N' PARTITION: ' + CAST(@partitionnum AS nvarchar(10)) + CHAR(13) + CHAR(10)
        SET @command = @command +
            N' PARTITION=' + CAST(@partitionnum AS nvarchar(10))
		END
    IF @frag >= @rebuild_frag_thresh AND @fill_factor > 0 AND @fill_factor < 100 AND @isonline =1  AND @isEnterprise	=	1
		BEGIN
        SET @intentions = @intentions +
            N' FILL FACTOR: ' + CAST(@fill_factor AS nvarchar) + CHAR(13) + CHAR(10)
        SET @command = @command +
            N' WITH (FILLFACTOR = ' + CAST(@fill_factor AS nvarchar) + ', ONLINE = ON)'
		END
           
     ELSE
            IF @frag >= @rebuild_frag_thresh AND @fill_factor > 0 AND @fill_factor < 100 AND @isonline =0
     BEGIN
        SET @intentions = @intentions +
            N' FILL FACTOR: ' + CAST(@fill_factor AS nvarchar) + CHAR(13) + CHAR(10)
        SET @command = @command +
            N' WITH (FILLFACTOR = ' + CAST(@fill_factor AS nvarchar) + ' )'
            
    END
 
    IF @report_only = 0 BEGIN
        SET @intentions = @intentions + N' EXECUTING: ' + @command
        PRINT @intentions	    
        EXEC (@command)
    END ELSE BEGIN
        PRINT @intentions
    END
	PRINT @command

END
 
CLOSE partitions
DEALLOCATE partitions
 
