DECLARE @MinCount BIGINT ;
SET @MinCount = 5000;
SELECT st.[text], qs.execution_count, qs.total_elapsed_time,
qs.execution_count/DATEDIFF(second, qs.creation_time,GetDate()) AS [Exec_Count_Per_Second]
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text( qs.sql_handle ) AS st
WHERE qs.execution_count > @MinCount --and st.[text] like '%SELECT CG.ID, CG.issueid%'
and (qs.execution_count/DATEDIFF(second, qs.creation_time,GetDate()))> 10
ORDER BY [Exec_Count_Per_Second] DESC;