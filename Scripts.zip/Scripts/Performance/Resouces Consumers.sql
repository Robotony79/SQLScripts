set transaction isolation level read uncommitted
;with DB_CPU_Stats
AS
(SELECT DatabaseID,
DB_Name(DatabaseID)AS [DatabaseName],
SUM(total_worker_time)AS [CPU_Time(Ms)]
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY(SELECT CONVERT(int, value)AS [DatabaseID]
 FROM sys.dm_exec_plan_attributes(qs.plan_handle)
 WHERE attribute ='dbid')AS epa
GROUP BY DatabaseID)
SELECT ROW_NUMBER()OVER(ORDER BY [CPU_Time(Ms)] DESC)AS [row_num],
DatabaseName,
[CPU_Time(Ms)],
CAST([CPU_Time(Ms)] * 1.0 /SUM([CPU_Time(Ms)])
OVER()* 100.0 AS DECIMAL(5, 2))AS [CPUPercent]
FROM DB_CPU_Stats
WHERE DatabaseID > 4 -- system databases
AND DatabaseID <> 32767 -- ResourceDB
ORDER BY row_num
OPTION(RECOMPILE);


/****** I/O Usage by database ****/
SELECT name AS'Database Name'
,SUM(num_of_reads)AS'Number of Reads'
,SUM(num_of_writes)AS'Number of Writes'
FROM sys.dm_io_virtual_file_stats(NULL,NULL) I
INNER JOIN sys.databases D ON I.database_id = D.database_id
GROUP BY name
ORDER BY 'Number of Reads'
DESC;

--Memory
DECLARE @total_buffer float;
SELECT @total_buffer = cntr_value
FROM sys.dm_os_performance_counters
WHERE RTRIM([object_name])LIKE'%Buffer Manager'
AND counter_name in('Database pages');
;WITH src AS
(SELECT database_id,
db_buffer_pages =COUNT_BIG(*)
FROM sys.dm_os_buffer_descriptors
      --WHERE database_id BETWEEN 5 AND 32766
GROUP BY database_id
)
SELECT [db_name] = CASE [database_id] WHEN 32767 THEN 'Resource DB' ELSE DB_NAME([database_id])END,
db_buffer_pages,
db_buffer_MB = db_buffer_pages / 128,
db_buffer_percent =CONVERT(DECIMAL(6,3),
db_buffer_pages * 100.0 / @total_buffer)
FROM src
ORDER BY db_buffer_MB DESC;