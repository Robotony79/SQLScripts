SELECT * FROM sys.dm_exec_query_resource_semaphores

SELECT * FROM sys.dm_exec_query_memory_grants
select top 10 * from sys.dm_exec_query_memory_grants where granted_memory_kb is not null

SELECT * FROM sys.dm_exec_sql_text(sql_handle)