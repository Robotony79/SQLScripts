USE [dw_efrl]
GO
select DB_NAME() AS [Current Database],OBJECT_NAME(s.object_id) AS [ObjectName],s.name,
STATS_DATE(s.object_id, [stats_id]) AS [StatisticUpdateDate]
FROM sys.stats s inner join sys.objects o on
s.object_id = o.object_id 
where o.type not in ('S','IT','SQ') and OBJECT_NAME(s.object_id) like '%T_F_XLE_FAH_DETAIL_AS_IS%' 
Order by [StatisticUpdateDate] desc

SELECT OBJECT_name(OBJECT_ID) TabName, 
       name IndexName,
       STATS_DATE(OBJECT_ID, index_id) AS StatsUpdated, type_desc, type, index_id,fill_factor,is_disabled
       --getdate() CheckTime
 FROM sys.indexes WHERE 
 --DATEDIFF(d,STATS_DATE(OBJECT_ID, index_id), getdate()) > 6 --and 
 OBJECT_name(OBJECT_ID) like '%T_F_XLE_FAH_DETAIL_AS_IS%'
 --name like '%t_f_XLG_AED_TRANSACTIONS_STG%'
-- object_id
-- in ('1358679938',
--'1490820373')
and is_disabled =1
 ORDER BY 3 DESC

 