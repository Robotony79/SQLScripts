﻿USE EDW
GO
select Distinct OBJECT_NAME(s.object_id) AS [ObjectName]
,DB_NAME() AS [Current Database]
,s.name
,STATS_DATE(s.object_id, [stats_id]) AS [StatisticUpdateDate]
,s.*
FROM sys.stats s inner join sys.objects o on
s.object_id = o.object_id 
where o.type not in ('S','IT','SQ') 
and OBJECT_NAME(s.object_id)IN (
'Dim_Inward_Policy_Section_Detail'
)
--and s.name in('_WA_Sys_00000071_42B7D1CC','_WA_Sys_00000070_42B7D1CC','XPK_t_f_xle_claim_transaction_detail_as_is')
--and DATEDIFF(d,STATS_DATE(s.object_id, [stats_id]),getdate())>2 and DATEDIFF(d,STATS_DATE(s.object_id, [stats_id]),getdate())<8
Order by [StatisticUpdateDate] desc

SELECT OBJECT_name(OBJECT_ID) TabName, 
       name IndexName,
       STATS_DATE(OBJECT_ID, index_id) AS StatsUpdated, type_desc, type, index_id,fill_factor,is_disabled
       --getdate() CheckTime
 FROM sys.indexes WHERE 
 DATEDIFF(d,STATS_DATE(OBJECT_ID, index_id), getdate()) > 6 and OBJECT_name(OBJECT_ID) not like '%sys%'
 --name like '%i_receipt%'
-- object_id
-- in ('1358679938',
--'1490820373')
 ORDER BY 3 DESC

 [‎10/‎8/‎2019 1:04 PM] WondieBizuye, Biniyam: 
brb Bro
update statistics t_claim_comment with fullscan
update statistics t_company with fullscan
update statistics t_event with fullscan
update statistics t_to_do_item with fullscan
update statistics t_user_nac_company with fullscan
update statistics t_claim_index with fullscan
update statistics  t_claim_layer with fullscan
update statistics  t_claim_comment with fullscan
update statistics t_user_nac_company with fullscan
update statistics t_user_nac_company with fullscan
update statistics t_lookups with fullscan
update statistics t_folder with fullscan
update statistics t_to_do_item with fullscan 
incase you need the tables



 update statistics [mdm].[t_storage_FinanceTransactionTypeCode_Hierarchy] WITH FULLSCAN--running
--update statistics T_F_TRANSACTIONS_USD WITH FULLSCAN-Running
--update statistics T_W_XLCD_NOTRANS_CLAIMS WITH FULLSCAN
--update statistics T_D_TRANSACTION_CATEGORY WITH FULLSCAN
--update statistics T_W_XLCD_TRANSACTION_CATEGORY WITH FULLSCAN
--update statistics T_F_CLAIM_ACTIVITIES WITH FULLSCAN-Running