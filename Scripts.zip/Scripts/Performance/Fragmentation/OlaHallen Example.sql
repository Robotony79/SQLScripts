exec admin.dbo.spu_dba_maintenance_main
@Databases = '%V_DB_NAME%', 
@FragmentationLevel1=5, 
@FragmentationLevel2=30, 
@MinNumberOfPages=500, 
@UpdateStatistics='ALL' ,
@OnlyModifiedStatistics='Y' ,
@DatabasesInParallel='Y' ,
@LogToTable='Y' ,
@Execute='Y'

select * from t_dba_maintenance_command_log
WHERE ObjectName in ('BrokerBalance')
--CommandType not in('UPDATE_STATISTICS')
order by StartTime desc