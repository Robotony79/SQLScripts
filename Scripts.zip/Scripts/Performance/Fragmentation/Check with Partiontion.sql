SELECT  object_id AS objectid ,
OBJECT_NAME(object_id) as Tablename,
            index_id AS indexid ,
            partition_number AS partitionnum ,
            avg_fragmentation_in_percent AS frag ,
            page_count AS page_count
    FROM    sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL,'LIMITED')
    WHERE   avg_fragmentation_in_percent > 30
            AND index_id > 0
            AND page_count > 100;

--t_f_xle_fah_detail_as_is 