USE [dw_efrl]
GO

select db_name(database_id),[statement],object_id,count([statement]) as #FINDINGS 
from sys.dm_db_missing_index_groups dm_mig 
INNER JOIN sys.dm_db_missing_index_group_stats dm_migs 
ON dm_migs.group_handle = dm_mig.index_group_handle 
INNER JOIN sys.dm_db_missing_index_details dm_mid 
ON dm_mig.index_handle = dm_mid.index_handle
where db_name(database_id)= 'dw_efrl'  and 
last_user_seek >= '2019-02-01 00:00' 
and ([statement] like '%Index_t_f_xle_conf_upd_fah_detail_as_is_stg_f1_23_201705%'
--or [statement]like '%CORE_BOM_VW%'
--or [statement]like '%T_F_CLAIM_ACTIVITIES%'
--or [statement]like '%T_D_CLAIM%'
--or [statement]like '%T_F_TRANSACTIONS_USD%'
--or [statement]like '%T_W_CLAIMS_DASHBOARD%'
--or [statement]like '%T_D_TRANSACTION_CATEGORY%'
--or [statement]like '%T_W_XLCD_TRANSACTION_CATEGORY%'
--or [statement]like '%T_W_XLCD_NOTRANS_CLAIMS%'
)
group by db_name(database_id),[statement],object_id
order by #FINDINGS desc

select [statement],[avg_user_impact],[user_seeks],[unique_compiles],[Last_user_seek],[Database_id] AS DB, 
[equality_columns],[inequality_columns],[included_columns] from sys.dm_db_missing_index_groups dm_mig 
INNER JOIN sys.dm_db_missing_index_group_stats dm_migs 
ON dm_migs.group_handle = dm_mig.index_group_handle 
INNER JOIN sys.dm_db_missing_index_details dm_mid 
ON dm_mig.index_handle = dm_mid.index_handle
where db_name(database_id)= 'dw_efrl' 
and last_user_seek >= '2019-02-01 00:00'
and ([statement] like '%Index_t_f_xle_conf_upd_fah_detail_as_is_stg_f1_23_201705%'
--or [statement]like '%CORE_BOM_VW%'
--or [statement]like '%T_F_CLAIM_ACTIVITIES%'
--or [statement]like '%T_D_CLAIM%'
--or [statement]like '%T_F_TRANSACTIONS_USD%'
--or [statement]like '%T_W_CLAIMS_DASHBOARD%'
--or [statement]like '%T_D_TRANSACTION_CATEGORY%'
--or [statement]like '%T_W_XLCD_TRANSACTION_CATEGORY%'
--or [statement]like '%T_W_XLCD_NOTRANS_CLAIMS%'
)
order by 
user_seeks Desc
--avg_user_impact
--avg_total_user_cost 

--VERIFY THE TABLE

SELECT  
        OBJECT_NAME(ps.object_id) AS object_name ,
        ps.index_id ,
        ISNULL(si.name, '(heap)') AS index_name ,
        CAST(ps.reserved_page_count * 8 / 1024. / 1024. AS NUMERIC(10, 2)) AS reserved_GB ,
        ps.row_count ,
        ps.partition_number ,
        ps.in_row_reserved_page_count ,
        ps.lob_reserved_page_count ,
        ps.row_overflow_reserved_page_count
FROM    sys.dm_db_partition_stats ps
        LEFT JOIN sys.indexes AS si
            ON ps.object_id = si.object_id
               AND ps.index_id = si.index_id
WHERE   OBJECT_NAME(ps.object_id) = 'T_F_XLE_FAH_DETAIL_AS_IS' 