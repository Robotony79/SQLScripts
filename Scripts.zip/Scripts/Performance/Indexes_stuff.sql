USE [xl_fsl_acctg_events_db]
GO

ALTER INDEX [UIX_t_f_XLG_AED_TRANSACTIONS_STG_1] ON [xlf].[t_f_XLG_AED_TRANSACTIONS_STG] DISABLE
GO

ALTER INDEX [NCI_t_s_XLG_AED_TRANSACTIONS_STG_BATCH_KEY] ON [xlf].[t_s_XLG_AED_TRANSACTIONS_STG] DISABLE
GO

update statistics xl_fsl_acctg_events_db.xlf.[t_f_XLG_AED_TRANSACTIONS_STG] 
-- Run a stored procedure or query


-- Find the plan handle for that query 
-- OPTION (RECOMPILE) keeps this query from going into the plan cache
SELECT cp.plan_handle, cp.objtype, cp.usecounts, 
DB_NAME(st.dbid) AS [DatabaseName]
FROM sys.dm_exec_cached_plans AS cp CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st 
WHERE OBJECT_NAME (st.objectid)
LIKE N'%SELECT%' 

OPTION (RECOMPILE); 

-- Remove the specific query plan from the cache using the plan handle from the above query 
DBCC FREEPROCCACHE (0x06000D00278F2612C078C28B4700000001000000000000000000000000000000000000000000000000000000);


SP