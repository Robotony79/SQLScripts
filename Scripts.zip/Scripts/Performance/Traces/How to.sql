use admin
go
EXEC Admin.dbo.spu_trc_Informatica @Folder = 'R:\DMS_INC1471514_20190930'

select * from fn_trace_getinfo(0)

select * FROM ::fn_trace_getinfo(default)

--sp_trace_setstatus [ @traceid = ] trace_id , [ @status = ] status

0 - Stops the specified trace.

1 - Starts the specified trace.

2 - Closes the specified trace and deletes its definition from the server. 

sp_trace_setstatus 2,2