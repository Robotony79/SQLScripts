use admin
go
exec CAS_DBA_trace @Folder = 'U:\Temp',@time_min=30
--To stop trace
EXEC sp_trace_setstatus @traceid =  2, @status = 0
