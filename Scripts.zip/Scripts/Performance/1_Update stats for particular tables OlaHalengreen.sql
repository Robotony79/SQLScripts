use admin
go

exec admin.dbo.spu_dba_maintenance_main
@Databases = 'xl_xcat_qa1',
@Indexes = 'dbo.t_res_results,
dbo.t_res_results_pml,
dbo.t_res_return_period_pml,
dbo.t_res_results_by_zone,
dbo.t_res_results_pml_by_zone,
dbo.t_res_return_period_pml_by_zone,
dbo.t_res_results_unadj,
dbo.t_res_results_pml_unadj,
dbo.t_res_return_period_pml_unadj',
@UpdateStatistics = 'ALL',
@OnlyModifiedStatistics= 'Y',
@LogToTable = 'Y'

--EXECUTE [dbo].[IndexOptimize]
--@Databases = 'USER_DATABASES',
--@Indexes = 'SalesDB.dbo.OrderStatus',
--@UpdateStatistics = 'ALL',
--@OnlyModifiedStatistics= '1',
--@LogToTable = 'Y'

--exec admin.dbo.spu_dba_maintenance_main @Databases = '%V_DB_NAME%', 
--@FragmentationLevel1=5, 
--@FragmentationLevel2=30, 
--@MinNumberOfPages=500, 
--@UpdateStatistics='ALL' ,
--@OnlyModifiedStatistics='Y' ,
--@DatabasesInParallel='Y' ,
--@LogToTable='Y' ,
--@Execute='Y'

DECLARE @Database VARCHAR(255)   
DECLARE @Table VARCHAR(255)  
DECLARE @cmd NVARCHAR(MAX)  
DECLARE @fillfactor INT 

--Specify the Database where the tables belong to
SET @Database = 'xl_xcat_qa1'
SET @fillfactor = 90 

SET @cmd = 'DECLARE TableCursor CURSOR FOR SELECT ''['' + table_catalog + ''].['' + table_schema + ''].['' + 
  table_name + '']'' as tableName FROM [' + @Database + '].INFORMATION_SCHEMA.TABLES 
  WHERE table_type = ''BASE TABLE''
  AND table_name IN(
''t_res_results'',
''t_res_results_pml'',
''t_res_return_period_pml'',
''t_res_results_by_zone'',
''t_res_results_pml_by_zone'',
''t_res_return_period_pml_by_zone'',
''t_res_results_unadj'',
''t_res_results_pml_unadj'',
''t_res_return_period_pml_unadj'')' 
	--delete "," and add "')" to below line   

   -- create table cursor  
   EXEC (@cmd)  
   --PRINT (@cmd)  
   OPEN TableCursor   
DECLARE @Statement NVARCHAR(300)
   FETCH NEXT FROM TableCursor INTO @Table   
   WHILE @@FETCH_STATUS = 0   
   BEGIN   
      	SET @cmd = 'UPDATE STATISTICS '+ @Table --+ ' WITH FULLSCAN '
		EXEC (@cmd)
		--PRINT (@cmd) 
       FETCH NEXT FROM TableCursor INTO @Table   
   END   
   CLOSE TableCursor   
   DEALLOCATE TableCursor