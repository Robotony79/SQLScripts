USE fcg_ods
GO

SELECT OBJECT_NAME(ind.OBJECT_ID) AS TableName, 
ind.name AS IndexName, indexstats.index_type_desc AS IndexType, 
indexstats.avg_fragmentation_in_percent, p.rows, a.total_pages, a.used_pages
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) indexstats 
INNER JOIN sys.indexes ind 
ON ind.object_id = indexstats.object_id 
AND ind.index_id = indexstats.index_id 
INNER JOIN sys.partitions p on ind.object_id = p.object_id and ind.index_id = p.index_id
INNER JOIN sys.allocation_units a ON p.partition_id = a.container_id
WHERE 
indexstats.avg_fragmentation_in_percent > 10 
and index_type_desc <> 'HEAP'
and rows > 500
--and 
--OBJECT_NAME(ind.object_id) IN (
--'Dim_Inward_Policy_Section_Detail'
----'t_res_f_income_expenses'
--)
ORDER BY indexstats.avg_fragmentation_in_percent DESC 


USE EDW_Extended
GO
select Distinct OBJECT_NAME(s.object_id) AS [ObjectName]
,DB_NAME() AS [Current Database]
,s.name
,STATS_DATE(s.object_id, [stats_id]) AS [StatisticUpdateDate]
FROM sys.stats s inner join sys.objects o on
s.object_id = o.object_id 
where o.type not in ('S','IT','SQ') 
and OBJECT_NAME(s.object_id) IN 
(
'Premium_Brokerage_UA_UV'
--,'loc'
--,'loccvg'
----,'t_int_policy_transaction_detail_new'
)
--and DATEDIFF(d,STATS_DATE(s.object_id, [stats_id]),getdate())>2 and DATEDIFF(d,STATS_DATE(s.object_id, [stats_id]),getdate())<8
Order by [StatisticUpdateDate] desc

--Additional actions
--IDX_t_lookup_values Failed in table [xact].[t_lookup_values] in database : xl_xact_profile_admin_app
--ALTER INDEX [IDX_t_lookup_values] ON [xact].[t_lookup_values] REBUILD  WITH (DATA_COMPRESSION = COLUMNSTORE)
--ALTER INDEX [IDX_t_profile_header_profile_set_key] ON [xact].[t_profile_header] REBUILD  WITH ( ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON )