set transaction isolation level read uncommitted 
SELECT 
	 db_name(r.database_id) [DB], r.wait_type,r.granted_query_memory,r.session_id,r.status--,r.cpu_time,r.total_elapsed_time,r.wait_time
	,st.TEXT AS batch_text
	,SUBSTRING(st.TEXT, statement_start_offset / 2 + 1, (
			(
				CASE 
					WHEN r.statement_end_offset = - 1
						THEN (LEN(CONVERT(NVARCHAR(max), st.TEXT)) * 2)
					ELSE r.statement_end_offset
					END
				) - r.statement_start_offset
			) / 2 + 1) AS statement_text
	,qp.query_plan AS 'XML Plan'
	,r.*
FROM sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS st
CROSS APPLY sys.dm_exec_query_plan(r.plan_handle) AS qp
--where r.session_id in ('131','124','157','109','151','160','148')
ORDER BY cpu_time DESC

--select * from sys.databases where database_id in (25)

--sp_who2 63