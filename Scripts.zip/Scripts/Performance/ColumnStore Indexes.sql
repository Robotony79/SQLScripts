SELECT    
       OBJECT_NAME(rg.object_id) AS TableName,
       i.name AS IndexName,
       i.type_desc AS IndexType,
       rg.row_group_id,
       rg.state,
       rg.state_description,
       rg.total_rows,
       rg.deleted_rows,
       rg.size_in_bytes
FROM      
       sys.column_store_row_groups AS rg
       INNER JOIN sys.indexes AS i
       ON i.object_id = rg.object_id AND i.index_id = rg.index_id
WHERE     
       i.type IN (5, 6) -- 5 = Clustered columnstore index. 6 = Nonclustered columnstore index.
ORDER BY  
       TableName, IndexName, rg.partition_number, rg.row_group_id;