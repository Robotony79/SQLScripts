SET NOCOUNT ON
go
SET ANSI_NULLS ON
GO

DECLARE @Database VARCHAR(255)   
DECLARE @Table VARCHAR(255)  
DECLARE @cmd NVARCHAR(MAX)  
DECLARE @fillfactor INT 

--Specify the Database where the tables belong to
SET @Database = 'staging_genius'
SET @fillfactor = 90 



SET @cmd = 'DECLARE TableCursor CURSOR FOR SELECT ''['' + table_catalog + ''].['' + table_schema + ''].['' + 
  table_name + '']'' as tableName FROM [' + @Database + '].INFORMATION_SCHEMA.TABLES 
  WHERE table_type = ''BASE TABLE''
  AND table_name IN(
''TransclaimOutwards'',
''PolicyDetails'',
''PolicySection'',
''MIS_MainLineCodes'',
''NamesAdditionalDetail'',
''ClaimHeader'',
''CoverageData'',
''BranchNames'',
''PolicySectionDetail'',
''ProducingOffices'',
''BrokerBalance'',
''TransClaimStatsOutwards'',
''AccountsHeader'',
''RiBordereauControl'')' 
	--delete "," and add "')" to below line   

   -- create table cursor  
   EXEC (@cmd)  
   --PRINT (@cmd)  
   OPEN TableCursor   
DECLARE @Statement NVARCHAR(300)
   FETCH NEXT FROM TableCursor INTO @Table   
   WHILE @@FETCH_STATUS = 0   
   BEGIN   
   		SET @cmd = 'UPDATE STATISTICS '+ @Table + ' WITH FULLSCAN '
		--EXEC @cmd
		PRINT (@cmd) 
       FETCH NEXT FROM TableCursor INTO @Table   
   END   

   CLOSE TableCursor   
   DEALLOCATE TableCursor  
