set transaction isolation level read uncommitted
                select top 50 @@servername,
                coalesce (db_name(st.dbid), db_name(convert (int, pa.value)),
'') as DBName,
left(replace(replace(replace(replace(replace(
SUBSTRING(st.text, (qs.statement_start_offset/2)+1,
        ((CASE qs.statement_end_offset
          WHEN -1 THEN DATALENGTH(st.text)
         ELSE qs.statement_end_offset
         END - qs.statement_start_offset)/2) + 1) 
         , char(10), ' ' ),char(13), ' ') ,char(11), ' '), char(9),' '), char(12),' '), 32000)
         AS StatementText,
         left(replace(replace(replace(replace(replace(
st.text 
, char(10), ' ' ),char(13), ' ') ,char(11), ' '), char(9),' '), char(12),' '),32000)
as ProcedureTextOrBatchText,
qs.execution_count as ExecutionCount,
(qs.total_worker_time/1000) as CPUTimeTotal_seconds,
(qs.total_elapsed_time/1000) as DurationTimeTotal_seconds,
(qs.total_physical_reads+qs.total_logical_reads+qs.total_logical_writes)
as TotalIO ,
qs.last_execution_time as LastExecutionTime   
from sys.dm_exec_query_stats qs
cross apply sys.dm_exec_sql_text(sql_handle) st
--cross apply sys.dm_exec_query_plan(plan_handle) qp
cross apply sys.dm_exec_plan_attributes(qs.plan_handle) pa
cross apply sys.dm_exec_plan_attributes(qs.plan_handle) pr
where pa.attribute = 'dbid'  and pr.attribute='objectid'
--and qs.last_execution_time >  dateadd (dd,-1, getdate() )
order by (qs.total_physical_reads+qs.total_logical_reads+qs.total_logical_writes)
desc


